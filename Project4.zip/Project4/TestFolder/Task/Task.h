#ifndef TASK_H
#define TASK_H
///////////////////////////////////////////////////////////////////////
// Task.h -executes a specified callable object on a ThreadPool thread//
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
Provides a Task class that executes a specified callable object on a ThreadPool thread, using services of the ThreadPool package

Public Interface:
=================
reset()                                                //resets the constructor parameters
wait()                                                 //Calls thread pool wait
signalStop() 							    //enqueues nullPtr
Build Process:
==============
Required files
- ThreadPool.h, ThreadPool.cpp, FunctorClass.h , FunctorClass.cpp, Cpp11-BlockingQueue.h, ThreadPCpp11-BlockingQueue.cpp,Task.h,Task.cpp
Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
#include "../FunctorClass/FunctorClass.h"
#include <string>
#include <iostream>
#include "../Utilities/Utilities.h"
#include "../ThreadPool/ThreadPool.h"

using WorkItm = FunctorClass;
class task
{
public:
	task(WorkItm* _pWi);
	~task() {}
	void reset() {
		first_ctor = true;
			}
	void wait();
	void signalStop();
private:
	static ProcessWorkItem processor;
	size_t numThreads;
	WorkItm *pWi;
	static bool first_ctor;
};

#endif