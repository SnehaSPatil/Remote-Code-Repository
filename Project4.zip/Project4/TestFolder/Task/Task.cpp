#include"Task.h"


///////////////////////////////////////////////////////////////
// Task constructor innitializes the threadpool parameters 
task::task(WorkItm* _pWi) :pWi(_pWi)
{
	if (first_ctor)
	{
		first_ctor = false;
		processor.setNumThreads(5);
		processor.start();
	}
	processor.doWork(_pWi);
}
ProcessWorkItem task::processor;
bool task::first_ctor = true;

/////////////////////////////
// Calls thread pool wait

void task::wait()
{
	processor.wait();
}

///////////////////////////////////////////////////////////////
//enqueues nullPtr indicating the end of workitems and asking the threads to stop 

void task::signalStop()
{
	for (size_t i = 0; i < 5; i++)
	{
		processor.doWork(nullptr);
	}
}

//Test Stub for Task Class

#ifdef TEST_TASKCLASS
#include "../FunctorClass/FunctorClass.h"
#include "../TypeAnalysis/TypeAnalysis.h"
#include "../Tasks/Task.h"

int main(int argc, char* argv[])
{
	std::cout << "\n  Testing DependencyAnalysis \n "
		<< std::string(30, '=') << std::endl;
	std::string fileSpec1 = "../Parser/Praser.cpp";
	std::string fileSpec2 = "../Parser/Praser.h";
	BlockingQueue<TypeTable<TypeTableRecord>*> q;

	FunctorClass depA1(fileSpec2, 1, &q);
	WorkItem &wi1 = depA1;
	task task1(&wi1);

	FunctorClass depA2(fileSpec2, 1, &q);
	WorkItem &wi2 = depA2;
	task task2(&wi2);
	task2.signalStop();
	task2.wait();
	task2.reset();
	typeAnalysis typeAlys;
	TypeTable<TypeTableRecord> SymboleTable;
	typeAlys.doMerge(SymboleTable, q);

	FunctorClass depA3(fileSpec2, 1, &q);
	WorkItem &wi3 = depA3;
	task task3(&wi3);
	task3.signalStop();
	task3.wait();
	task3.reset();
}
#endif