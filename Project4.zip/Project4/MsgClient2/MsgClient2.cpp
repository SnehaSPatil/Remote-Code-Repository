/////////////////////////////////////////////////////////////////////////
// MsgClient2.cpp - Demonstrates simple one-way HTTP messaging         //
// Author : Sneha Pati, CSE                                            //
// Source :Jim Fawcett, CSE687 - Object Oriented Design, Spring 2016   //
// Application: OOD Project #4 Dependency-Based Remote Code Repository //
// Platform:    Visual Studio 2015, Dell XPS 8900, Windows 10 pro      //
/////////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
* This package implements a client that sends HTTP style messages and
* files to a server that simply displays messages and stores files.
*
* It's purpose is to provide a very simple illustration of how to use
* the Socket Package provided for Project #4.
*/
/*
Build Process:
==============

* Required Files:
*   MsgClient.cpp, MsgServer.cpp
*   HttpMessage.h, HttpMessage.cpp
*   Cpp11-BlockingQueue.h
*   Sockets.h, Sockets.cpp
*   FileSystem.h, FileSystem.cpp
*   Logger.h, Logger.cpp
*   Utilities.h, Utilities.cpp

Build commands
- devenv Project4.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16

*/

#include "../HttpMessage/HttpMessage.h"
#include "../Sockets/Sockets.h"
#include "../FileSystem/FileSystem.h"
#include "../Logger/Logger.h"
#include "../Utilities/Utilities.h"
#include <string>
#include <iostream>
#include <thread>

using Show = StaticLogger<1>;
using namespace Utilities;
using Utils = StringHelper;

/////////////////////////////////////////////////////////////////////
// ClientCounter creates a sequential number for each client
//
class ClientCounter
{
public:
	ClientCounter() { ++clientCount; }
	size_t count() { return clientCount; }
private:
	static size_t clientCount;
};

size_t ClientCounter::clientCount = 0;

/////////////////////////////////////////////////////////////////////
// MsgClient class
// talks to the server

class MsgClient
{
public:
	using EndPoint = std::string;
	void receiver();
	MsgClient(EndPoint myEdPoint, EndPoint SEndPoint) :myEndPoint(myEdPoint), ServerEndPoint(SEndPoint) {};
	void sendDependencyist(Socket& socket, const std::string& packageName, std::vector<std::string> dependencylist);
	void execute();
	void packageCheckin(Socket& socket, const std::string& packageName, std::string filepath);
	void extractPackage(Socket& socket, const std::string& packageName, std::string withDependencies);
	void closeCheckin(Socket& socket, const std::string& packageName);
	std::vector<std::string> getFilelist(Socket& si, std::string command);
private:
	void verSion1(Socket& socket, const std::string& packageName, std::string filepath);
	void verSion2(Socket& socket, const std::string& packageName, std::string filepath);
	EndPoint myEndPoint;
	EndPoint ServerEndPoint;
	std::string FileList;
	void checkin(Socket& socket, const std::string& packageName, std::string filepath);
	void extraction(Socket& socket, const std::string& packageName, std::string filepath);
	HttpMessage makeMessage(size_t n, const std::string& msgBody, const EndPoint& ep);
	void sendMessage(HttpMessage& msg, Socket& socket);
	bool sendFile(const std::string& fqname, const std::string& packagePath, Socket& socket, std::string packageName);
};

/////////////////////////////////////////////////////////////////////
// serVerHandler class
// handles the messages received from the server

class serVerHandler
{
public:
	serVerHandler(BlockingQueue<HttpMessage>& msgQ) : msgQ_(msgQ) {}
	void operator()(Socket socket);
private:
	bool connectionClosed_;
	HttpMessage readMessage(Socket& socket);
	void readMessageHelper1(Socket& socket, HttpMessage& msg);
	void readMessageHelper2(Socket& socket, HttpMessage& msg);
	void readMessageHelper3(Socket& socket, HttpMessage& msg);
	void readMessageHelper4(Socket& socket, HttpMessage& msg);
	bool readFile(const std::string& package, const std::string& filename, size_t fileSize, Socket& socket);
	BlockingQueue<HttpMessage>& msgQ_;
};

//<........Parses the file sting to get the list of dependencies......>

std::vector<std::string> parseFileString(std::string msg)
{
	std::vector<std::string> body;
	size_t i = msg.find("\t\t");
	i += 2;
	while (i < msg.size())
	{
		size_t j = i;
		std::string value;
		for (; msg[j] != '\t' && j < msg.size(); j++)
		{
			value = value + msg[j];
		}
		i = j;
		body.push_back(value);
		i++;
	}
	return body;
}


//<.......converts the package list to string......>


std::string getFileString(std::vector<std::string>& body)
{
	std::string  message = "\t\t";
	for (size_t i = 0; i < body.size(); i++)
	{
		message = message + body[i];
		message = message + "\t";
	}
	return message;
}


// sends the checkin or extract command  and asks for package list and returns it

std::vector<std::string> MsgClient::getFilelist(Socket& si, std::string command)
{
	HttpMessage msg1 = makeMessage(1, "", ServerEndPoint);
	msg1.addAttribute(HttpMessage::Attribute("sendFileList", command));
	sendMessage(msg1, si);
	receiver();
	std::vector<std::string> FileL = parseFileString(FileList);
	std::vector<std::string> File2;
	Show::write("\n Package List received  from the server - ");
	for (size_t i = 0; i < FileL.size(); i++)
	{
		if (!(FileL[i] == "." || FileL[i] == ".."))
		{
			Show::write("\n" + FileL[i]);
			File2.push_back(FileL[i]);
		}
	}
	return File2;
}

//<.......Sends the closed checkin command......>

void MsgClient::closeCheckin(Socket& socket, const std::string& packageName)
{
	HttpMessage msg = makeMessage(1, "", ServerEndPoint);
	msg.addAttribute(HttpMessage::Attribute("Close", packageName));
	sendMessage(msg, socket);
}

//<.......Sends the extract package command and switches on the receiver......>

void MsgClient::extractPackage(Socket& socket, const std::string& packageName, std::string withDependencies)
{
	HttpMessage msg = makeMessage(1, "", ServerEndPoint);
	msg.addAttribute(HttpMessage::Attribute("Extraction", packageName));
	msg.addAttribute(HttpMessage::Attribute("withDependencies", withDependencies));
	sendMessage(msg, socket);
	receiver();
}


//<.......Sends the dependency list.....>

void MsgClient::sendDependencyist(Socket& socket, const std::string& packageName, std::vector<std::string> dependencylist)
{
	std::string deps;
	if (dependencylist.size() == 0)
		deps = "NULL";
	else
	{
		deps = getFileString(dependencylist);
	}
	HttpMessage msg1 = makeMessage(1, "", ServerEndPoint);
	msg1.addAttribute(HttpMessage::Attribute("Package", packageName));
	msg1.addAttribute(HttpMessage::Attribute("Dependency", deps));
	sendMessage(msg1, socket);
}


//----< read a binary file from socket and save >--------------------
/*
* This function expects the sender to have already send a file message,
* and when this function is running, continuosly send bytes until
* fileSize bytes have been sent.
*/

bool serVerHandler::readFile(const std::string& package, const std::string& filename, size_t fileSize, Socket& socket)
{
	if (!FileSystem::Directory::exists("../clientDump2/" + package))
		FileSystem::Directory::create("../clientDump2/" + package);
	std::string fqname = "../clientDump2/" + package + "/" + filename;
	FileSystem::File file(fqname);
	file.open(FileSystem::File::out, FileSystem::File::binary);
	const size_t BlockSize = 2048;
	Socket::byte buffer[BlockSize];
	size_t bytesToRead;
	while (true)
	{
		if (fileSize > BlockSize)
			bytesToRead = BlockSize;
		else
			bytesToRead = fileSize;
		socket.recv(bytesToRead, buffer);
		FileSystem::Block blk;
		for (size_t i = 0; i < bytesToRead; ++i)
			blk.push_back(buffer[i]);
		if (file.isGood())
			file.putBlock(blk);
		if (fileSize < BlockSize)
			break;
		fileSize -= BlockSize;
	}
	file.close();
	return true;
}

//----<Reads message attributes helper it handles the receivin gof packages from server >---------

void serVerHandler::readMessageHelper1(Socket& socket, HttpMessage& msg)
{
	std::string filename = msg.findValue("file");
	size_t contentSize;
	std::string sizeString = msg.findValue("content-length");
	if (sizeString != "")
		contentSize = Converter<size_t>::toValue(sizeString);
	else
		return;
	std::string Package = msg.findValue("Package");
	readFile(Package, filename, contentSize, socket);
	msg.removeAttribute("content-length");
	std::string bodyString = "<file>" + filename + "</file>";
	sizeString = Converter<size_t>::toString(bodyString.size());
	msg.addAttribute(HttpMessage::Attribute("content-length", sizeString));
	msg.addBody(bodyString);
}

//----<Reads message attributes helper it handles the receivingof package list from server >---------

void serVerHandler::readMessageHelper2(Socket& socket, HttpMessage& msg)
{
	std::string filename = msg.findValue("file");
	std::string fileList = msg.findValue("fileList");
	msg.removeAttribute("content-length");
	std::string bodyString = "<file>" + filename + "</file>";
	std::string sizeString = Converter<size_t>::toString(bodyString.size());
	msg.addAttribute(HttpMessage::Attribute("content-length", sizeString));
	msg.addBody(bodyString);
}

//----<Reads message attributes helper  >---------

void serVerHandler::readMessageHelper3(Socket& socket, HttpMessage& msg)
{
	size_t numBytes = 0;
	size_t pos = msg.findAttribute("content-length");
	if (pos < msg.attributes().size())
	{
		numBytes = Converter<size_t>::toValue(msg.attributes()[pos].second);
		Socket::byte* buffer = new Socket::byte[numBytes + 1];
		socket.recv(numBytes, buffer);
		buffer[numBytes] = '\0';
		std::string msgBody(buffer);
		msg.addBody(msgBody);
		delete[] buffer;
	}
}

//----<Reads message attributes helper it handles the post messages >---------
void serVerHandler::readMessageHelper4(Socket& socket, HttpMessage& msg)
{
	std::string filename = msg.findValue("file");
	std::string fileList = msg.findValue("fileList");
	if (filename != "")
	{
		readMessageHelper1(socket, msg);
		return;
	}
	if (fileList != "")
		return;
	if (filename != "")			// construct message body
		readMessageHelper2(socket, msg);
	else						// read message body
		readMessageHelper3(socket, msg);
}


//<***************** read message attributes*****************>
HttpMessage serVerHandler::readMessage(Socket& socket)
{
	connectionClosed_ = false;
	HttpMessage msg;
	while (true)
	{
		std::string attribString = socket.recvString('\n');
		if (attribString.size() > 1)
		{
			HttpMessage::Attribute attrib = HttpMessage::parseAttribute(attribString);
			msg.addAttribute(attrib);
		}
		else
			break;
	}
	// If client is done, connection breaks and recvString returns empty string
	if (msg.attributes().size() == 0)
	{
		connectionClosed_ = true;
		return msg;
	}
	// read body if POST - all messages in this demo are POSTs
	if (msg.attributes()[0].first == "POST")
	{
		readMessageHelper4(socket, msg);
		return msg;
	}
	return msg;
}


//----< receiver functionality is defined by this function >---------

void serVerHandler::operator()(Socket socket)
{
	while (true)
	{
		HttpMessage msg = readMessage(socket);
		msgQ_.enQ(msg);
		if (connectionClosed_ || msg.bodyString() == "quit")
		{
			//Show::write("\n\n  erverhandler thread is terminating");
			break;
		}
	}
	socket.shutDownRecv();
}



//----< Receiver for the Client >------------------------------

void MsgClient::receiver()
{
	Show::attach(&std::cout);
	Show::start();
	Show::title("\n  HttpMessage started");
	BlockingQueue<HttpMessage> msgQ;
	try
	{
		SocketSystem ss;
		SocketListener sl(8082, Socket::IP6);
		serVerHandler cp(msgQ);
		sl.start(cp);

		while (true)
		{
			HttpMessage msg = msgQ.deQ();
			std::string fileList = msg.findValue("fileList");
			if (fileList != "")
			{
				FileList = fileList;
			}
			if (msg.bodyLength() > 0 && msg.bodyString() != "quit")
				Show::write("\n\n  client recvd message contents:\n" + msg.bodyString());
			if (msg.bodyString() == "quit")
			{
				//	Show::write("\n\n  serverhandler thread is terminating");
				break;
			}
		}

	}
	catch (std::exception& exc)
	{
		Show::write("\n  Exeception caught: ");
		std::string exMsg = "\n  " + std::string(exc.what()) + "\n\n";
		Show::write(exMsg);
	}
}

//----< Handles the package check in >------------------------------

void MsgClient::packageCheckin(Socket& si, const std::string& packageName, std::string filepath)
{

	std::vector<std::string> files = FileSystem::Directory::getFiles(filepath, "*.cpp");
	std::vector<std::string> files1 = FileSystem::Directory::getFiles(filepath, "*.h");
	for (size_t i = 0; i < files1.size(); ++i)
	{
		files.push_back(files1[0]);
	}
	for (size_t i = 0; i < files.size(); ++i)
	{
		Show::write("\n\n  sending file " + files[i]);
		sendFile(files[i], filepath, si, packageName);
	}
}


//----< factory for creating messages >------------------------------

HttpMessage MsgClient::makeMessage(size_t n, const std::string& body, const EndPoint& ep)
{
	HttpMessage msg;
	HttpMessage::Attribute attrib;
	switch (n)
	{
	case 1:
		msg.clear();
		msg.addAttribute(HttpMessage::attribute("POST", "Message"));
		msg.addAttribute(HttpMessage::Attribute("mode", "oneway"));
		msg.addAttribute(HttpMessage::parseAttribute("toAddr:" + ep));
		msg.addAttribute(HttpMessage::parseAttribute("fromAddr:" + myEndPoint));
		msg.addBody(body);
		if (body.size() > 0)
		{
			attrib = HttpMessage::attribute("content-length", Converter<size_t>::toString(body.size()));
			msg.addAttribute(attrib);
		}
		break;
	default:
		msg.clear();
		msg.addAttribute(HttpMessage::attribute("Error", "unknown message type"));
	}
	return msg;
}


//----< send message using socket >----------------------------------

void MsgClient::sendMessage(HttpMessage& msg, Socket& socket)
{
	std::string msgString = msg.toString();
	socket.send(msgString.size(), (Socket::byte*)msgString.c_str());
}


//----< send file using socket >-------------------------------------
/*
* - Sends a message to tell receiver a file is coming.
* - Then sends a stream of bytes until the entire file
*   has been sent.
* - Sends in binary mode which works for either text or binary.
*/
bool MsgClient::sendFile(const std::string& filename, const std::string& packagePath, Socket& socket, std::string packageName)
{
	// assumes that socket is connected

	std::string fqname = packagePath + "/" + filename;
	FileSystem::FileInfo fi(fqname);
	size_t fileSize = fi.size();
	std::string sizeString = Converter<size_t>::toString(fileSize);
	FileSystem::File file(fqname);
	file.open(FileSystem::File::in, FileSystem::File::binary);
	if (!file.isGood())
		return false;
	HttpMessage msg = makeMessage(1, "", ServerEndPoint);
	msg.addAttribute(HttpMessage::Attribute("file", filename));
	msg.addAttribute(HttpMessage::Attribute("Package", packageName));
	msg.addAttribute(HttpMessage::Attribute("content-length", sizeString));
	sendMessage(msg, socket);
	const size_t BlockSize = 2048;
	Socket::byte buffer[BlockSize];
	while (true)
	{
		FileSystem::Block blk = file.getBlock(BlockSize);
		if (blk.size() == 0)
			break;
		for (size_t i = 0; i < blk.size(); ++i)
			buffer[i] = blk[i];
		socket.send(blk.size(), buffer);
		if (!file.isGood())
			break;
	}
	file.close();
	return true;
}

//----< executes the checkin process >----------------------------------


void MsgClient::checkin(Socket& si, const std::string& packageName, std::string PackagePath)
{
	Show::write("\n\n\n");
	Show::write("\n************************************************************************");
	Show::write("\n*******Demonstrating Open Close property Requirement 6*********************************");
	Show::write("\n************************************************************************");
	Show::write("\nCheckin command to the serve");
	Show::write("\nPackage selected for check in - " + packageName);
	std::vector <std::string> PackList = getFilelist(si, "Checkin");
	Show::write("\n Package seleected as dependencies - \n" + PackList[2] + "\n" + PackList[3]);
	std::vector<std::string> body1;
	body1.push_back(PackList[2]);
	body1.push_back(PackList[3]);
	packageCheckin(si, packageName, PackagePath);
	sendDependencyist(si, packageName, body1);
	Show::write("\n*******check in still open adding more fies to package**********");
	packageCheckin(si, packageName, "../Logger");
	Show::write("\n****Since the checkin isn't closed by the client the Repository does not");
	Show::write("\n transfer this file to the immutable repository area***************");
	Show::write("\n************************************************************************");
}


//----< executes the checkin process for various versins >----------------------------------

void MsgClient::verSion1(Socket& si, const std::string& packageName, std::string PackagePath)
{
	Show::write("\n************************************************************************");
	Show::write("\nDemonstrating CHECKIN of Package "+ packageName+ " creating 1st versions");
	Show::write("\n************************************************************************");
	Show::write("\nCheckin command to the serve");
	Show::write("\nPackage selected for check in - " + packageName);
	std::vector <std::string> PackList = getFilelist(si, "Checkin");
	Show::write("\n Package seleected as dependencies - \n" + PackList[2] + "\n" + PackList[3]);
	std::vector<std::string> body1;
	body1.push_back(PackList[2]);
	body1.push_back(PackList[3]);
	packageCheckin(si, packageName, PackagePath);
	sendDependencyist(si, packageName, body1);
	closeCheckin(si, packageName);
	Show::write("\n*******Closing check in Packag contents are now immutable***************");
	Show::write("\n************************************************************************");
}

//----< executes the checkin process for various versins >----------------------------------

void MsgClient::verSion2(Socket& si, const std::string& packageName, std::string PackagePath)
{
	Show::write("\n\n\n");
	Show::write("\n************************************************************************");
	Show::write("\nDemonstrating CHECKIN of Package " + packageName + " creating 2nd versions");
	Show::write("\n************************************************************************");
	Show::write("\nCheckin command to the serve");
	Show::write("\nPackage selected for check in - " + packageName);
	std::vector <std::string> PackList = getFilelist(si, "Checkin");
	Show::write("\n Package seleected as dependencies - \n" + PackList[2] + "\n" + PackList[3]);
	std::vector<std::string> body1;
	body1.push_back(PackList[2]);
	body1.push_back(PackList[3]);
	packageCheckin(si, packageName, PackagePath);
	sendDependencyist(si, packageName, body1);
	closeCheckin(si, packageName);
	Show::write("\n*******Closing check in Packag contents are now immutable***************");
	Show::write("\n************************************************************************");
}


void MsgClient::extraction(Socket& si, const std::string& packageName, std::string PackagePath)
{
	Show::write("\n*************************************************************************");
	Show::write("\n***Demonstrating EXTRACTION of Package WITHOUT Dependencies Reuirement 7 *");
	Show::write("\n*************************************************************************");
	Show::write("\n extract command to the serve");
	std::vector <std::string> PackList = getFilelist(si, "Extract");
	Show::write("\nPackage selected for extraction WITHOUT dependencies" + PackList[3]);
	extractPackage(si, PackList[3], "false");
	Show::write("\n************************************************************************");
}

//----< this defines the behavior of the client >--------------------

void MsgClient::execute()
{
	// send NumMessages messages
	HttpMessage::Attribute address = HttpMessage::parseAttribute(ServerEndPoint);
	const char* ipAddress = (address.second).c_str();
	size_t portNum = atoi(ipAddress);

	std::string PackagePath = "../TestFolder/TestFiles";
	std::string PackageName = "TestFiles";
	Show::attach(&std::cout);
	Show::start();
	try
	{
		SocketSystem ss;
		SocketConnecter si;
		while (!si.connect(address.first, portNum))
		{
			Show::write("\n client waiting to connect");
			::Sleep(100);
		}
		// send a set of messages
		HttpMessage msg;
		//  send all *.cpp files from TestFiles folder
		verSion1(si, PackageName, PackagePath);
		verSion2(si, PackageName, PackagePath);
		extraction(si, PackageName, PackagePath);
		PackagePath = "../TestFolder/Logger";
		PackageName = "Logger";
		checkin(si, PackageName, PackagePath);
		msg = makeMessage(1, "quit", ServerEndPoint);
		Show::write("\n\n  client" + myEndPoint + " sent\n" + msg.toIndentedString());
		Show::write("\n**************************************************************************");
		Show::write("\n*****Reuirement 8, 9, 10 have been met by using the http oneway message passing**");
		Show::write("\n*****Reuirement 2, 11 have been demonstrated in code implementation and 3 by creating xml document*");
		Show::write("\n*************************************************************************");
		sendMessage(msg, si);
		Show::write("\n");
		//Show::write("\n  All done folks");
	}
	catch (std::exception& exc)
	{
		Show::write("\n  Exeception caught: ");
		std::string exMsg = "\n  " + std::string(exc.what()) + "\n\n";
		Show::write(exMsg);
	}
}
//----< entry point - runs two clients each on its own thread >------

int main()
{
	::SetConsoleTitle(L"Clients with port address localhost:8082");
	MsgClient c1("localhost:8082", "localhost:8080");
	std::thread t1(
		[&]() { c1.execute(); } // 20 messages 100 millisec apart
	);
	t1.join();
	std::cin.get();
}