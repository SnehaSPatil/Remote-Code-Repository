/////////////////////////////////////////////////////////////////////////
// MsgServer.cpp - Demonstrates simple one-way HTTP style messaging    //
//                 and file transfer                                   //
// Author : Sneha Pati, CSE  spatil01@syr.edu                          //
//                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2016           //
// Application: OOD Project #4 Dependency-Based Remote Code Repository //
// Platform:    Visual Studio 2015, Dell XPS 8900, Windows 10 pro      //
/////////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
* This package implements a server that receives HTTP style messages and
* files from multiple concurrent clients and simply displays the messages
* and stores files.
*
* It's purpose is to provide a very simple illustration of how to use
* the Socket Package provided for Project #4.
*/
/*
Build Process:
==============
* Required Files:
*   MsgClient.cpp, MsgServer.cpp
*   HttpMessage.h, HttpMessage.cpp
*   Cpp11-BlockingQueue.h
*   Sockets.h, Sockets.cpp
*   FileSystem.h, FileSystem.cpp
*   Logger.h, Logger.cpp 
*   Utilities.h, Utilities.cpp

Build commands
- devenv Project4.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/


#include "../HttpMessage/HttpMessage.h"
#include "../Sockets/Sockets.h"
#include "../FileSystem/FileSystem.h"
#include "../Logger/Cpp11-BlockingQueue.h"
#include "../Logger/Logger.h"
#include "../Utilities/Utilities.h"
#include <string>
#include <iostream>
#include "../XmlWriter/XmlWriter.h"
#include "../XmlReader/XmlReader.h"
#include <winbase.h>
#include<Windows.h>
#include<iomanip>
#include<utility>
#include<ctime>
#include <unordered_map>

using Show = StaticLogger<1>;
using namespace Utilities;

/////////////////////////////////////////////////////////////////////
// Message sender class : Sends the file ist and the 
//pakage to be extracted to the client
/////////////////////////////////////////////////////////////////////


class MsgSender
{
public:
	using EndPoint = std::string;
	void executeExtraction(std::string packageeName, std::string sendAddress, std::string withDependencies);
	void sendFileList(std::string sendAddress);
	MsgSender(EndPoint myEdPoint) :myEndPoint(myEdPoint) {};
private: 
	void extractDependencies(Socket& socket, const std::string& packageName, std::string filepath, std::unordered_map<std::string, bool>& PackagestoSend);
	void packageExtraction(Socket& socket, const std::string& packageName, std::string filepath, std::string withDependencies);
	HttpMessage makeMessage(size_t n, const std::string& msgBody, const EndPoint& ep);
	void sendMessage(HttpMessage& msg, Socket& socket);
	bool sendFile(const std::string& fqname, const std::string& packageName, Socket& socket);
	EndPoint myEndPoint;
};


/////////////////////////////////////////////////////////////////////
// ClientHandler class : handles the reuests of the incoming mssages
//sent by vaarious clients
/////////////////////////////////////////////////////////////////////

class ClientHandler
{
public:
	ClientHandler(BlockingQueue<HttpMessage>& msgQ) : msgQ_(msgQ) {}
	void operator()(Socket socket);
	void createXMLDocument(std::vector<std::string> deps, std::string package);
private:
	bool connectionClosed_;
	void ClosingCheckin(std::string packagename);
	HttpMessage readMessage(Socket& socket);
	void readMessageHelper1(Socket& socket, HttpMessage& msg);
	void readMessageHelper2(Socket& socket, HttpMessage& msg);
	void readMessageHelper3(Socket& socket, HttpMessage& msg);
	void readMessageHelper4(Socket& socket, HttpMessage& msg);
	void readMessageHelper5(Socket& socket, HttpMessage& msg);
	void readMessageHelper6(Socket& socket, HttpMessage& msg);
	bool readFile(const std::string& package, const std::string& filename, size_t fileSize, Socket& socket);
	BlockingQueue<HttpMessage>& msgQ_;
};

//<.......converts the package list to string......>

std::string getFileString(std::vector<std::string> body)
{
	std::string  message = "\t\t";
	for (size_t i = 0; i < body.size(); i++)
	{
		message = message + body[i];
		message = message + "\t";
	}
	return message;
}

//<........Parses the file sting to get the list of dependencies......>

std::vector<std::string> parseFileString(std::string msg)
{
	size_t i = msg.find("\t\t");
	i += 1;

	std::vector<std::string> body;
	while (i < msg.size())
	{
		size_t j = i;
		std::string value;
		for (; msg[j] != '\t' && j < msg.size(); j++)
		{
			value = value + msg[j];
		}
		i = j;
		body.push_back(value);
		i++;
	}
	return body;
}

//<........Sends the file list to client......>
/*Connects to the client and sends the file list*/

void MsgSender::sendFileList(std::string sendAddress)
{
	HttpMessage::Attribute address = HttpMessage::parseAttribute(sendAddress);
	const char* ipAddress = (address.second).c_str();
	size_t portNum = atoi(ipAddress);
	Show::attach(&std::cout);
	Show::start();
	try
	{
		SocketSystem ss;
		SocketConnecter si;
		while (!si.connect(address.first, portNum))
		{
			Show::write("\n client waiting to connect");
			::Sleep(100);
		}
		// send a set of messages
		HttpMessage msg;
		//  send all *.cpp files from TestFiles folder
		std::string filepath = "../RemoteRepository";
		std::vector<std::string> files = FileSystem::Directory::getDirectories(filepath);
		Show::write("\n server sending package list");
		std::string filelist = getFileString(files);
		HttpMessage msg2;
		msg2 = makeMessage(1, "", sendAddress);
		msg2.addAttribute(HttpMessage::Attribute("fileList", filelist));
		sendMessage(msg2, si);
		msg = makeMessage(1, "quit", sendAddress);
		sendMessage(msg, si);
		Show::write("\n");
		//Show::write("\n  All done folks");
	}
	catch (std::exception& exc)
	{
		Show::write("\n  Exeception caught: ");
		std::string exMsg = "\n  " + std::string(exc.what()) + "\n\n";
		Show::write(exMsg);
	}
	
}

//<........execute the extraction ......>
/*Connects to the client and starts the package sending*/

void MsgSender::executeExtraction(std::string packageeName, std::string sendAddress, std::string withDependencies)
{
	// send NumMessages messages
	HttpMessage::Attribute address = HttpMessage::parseAttribute(sendAddress);
	const char* ipAddress = (address.second).c_str();
	size_t portNum = atoi(ipAddress);
	Show::attach(&std::cout);
	Show::start();
	try
	{
		SocketSystem ss;
		SocketConnecter si;
		while (!si.connect(address.first, portNum))
		{
			Show::write("\n client waiting to connect");
			::Sleep(100);
		}
		// send a set of messages
		HttpMessage msg;
	   //  send all *.cpp and  *.h  files from required folders
		packageExtraction(si, packageeName, "../RemoteRepository/"+ packageeName, withDependencies);
		msg = makeMessage(1, "quit", sendAddress);
		sendMessage(msg, si);
     	Show::write("\n");
		//Show::write("\n  All done folks");
	}
	catch (std::exception& exc)
	{
		Show::write("\n  Exeception caught: ");
		std::string exMsg = "\n  " + std::string(exc.what()) + "\n\n";
		Show::write(exMsg);
	}
}

//<........Converts the text file to the string ......>

std::string textFileToString(const std::string& fileName)
{
	std::ifstream in(fileName);
	if (!in.good())
	{
		std::cout << "\ncan't open source file " + fileName << "\n";
		return 0;
	}
	std::ostringstream out;
	out << in.rdbuf();
	return std::move(out.str());
}


//<........ Reads the XML document and gives the dependecy list stored in the xml ......>

std::vector<std::string> readXMLDocument(std::string package, std::string packageName)
{
	std::string src = package + "/" + packageName;
	std::string test1 = textFileToString(src);
	XmlReader rdr(test1);
	std::string ident;
	size_t position = 1;
	std::vector<std::string> dependencyVec;
	do
	{
		ident = rdr.extractIdentifier(position);
	} while (ident.size() > 0);
	rdr.reset();
	while (rdr.next())
	{
		rdr.element().c_str();
		//reds the tag dep 
		if (rdr.tag() == "dep")
		{
			dependencyVec.push_back(rdr.body());
		}
		XmlReader::attribElems attribs = rdr.attributes();
	}
	return dependencyVec;
}


//<........ Extracting the package from the repository ......>

void MsgSender::packageExtraction(Socket& si, const std::string& packageName, std::string Packagepath, std::string withDependencies)
{
	Show::write("\n server sending requested package " + packageName);
	std::unordered_map<std::string, bool> PackagestoSend;
	PackagestoSend.insert(std::make_pair(packageName, true));
	if (withDependencies == "true")
		extractDependencies(si, packageName, Packagepath, PackagestoSend);
	auto recordItr = PackagestoSend.begin();
	for (auto recordItr : PackagestoSend)
	{
		if (recordItr.first == packageName || withDependencies == "true")
		{
			std::vector<std::string> files = FileSystem::Directory::getFiles("../RemoteRepository/" + recordItr.first, "*.cpp");
			std::vector<std::string> files1 = FileSystem::Directory::getFiles("../RemoteRepository/" + recordItr.first, "*.h");
			for (size_t i = 0; i < files1.size(); ++i)
			{
				files.push_back(files1[0]);
			}
			for (size_t i = 0; i < files.size(); ++i)
			{
				Show::write("\n\n  sending file " + files[i]);
				sendFile(files[i], recordItr.first, si);
			}
		}
	}
}

//<........ Extracting the dependent packages from the repository ......>
/*Recursive function that gives the ccomplete dependency list*/
void MsgSender::extractDependencies(Socket& si, const std::string& packageName, std::string Packagepath, std::unordered_map<std::string, bool>& PackagestoSend)
{
	std::vector<std::string> XMLfile = FileSystem::Directory::getFiles(Packagepath, "*.xml");
	if (XMLfile.size() > 0)
	{
		std::vector<std::string> dependency = readXMLDocument(Packagepath, XMLfile[0]);
		for (size_t i = 0; i < dependency.size(); i++)
		{
			if (dependency[i] == "NULL")
				continue;
			PackagestoSend.insert(std::make_pair(dependency[i], true));
			extractDependencies(si, packageName, "../RemoteRepository/" + dependency[i], PackagestoSend);
		}
	}
}

//----< factory for creating messages >------------------------------

HttpMessage MsgSender::makeMessage(size_t n, const std::string& body, const EndPoint& ep)
{
	HttpMessage msg;
	HttpMessage::Attribute attrib;
	switch (n)
	{
	case 1:
		msg.clear();
		msg.addAttribute(HttpMessage::attribute("POST", "Message"));
		msg.addAttribute(HttpMessage::Attribute("mode", "oneway"));
		msg.addAttribute(HttpMessage::parseAttribute("toAddr:" + ep));
		msg.addAttribute(HttpMessage::parseAttribute("fromAddr:" + myEndPoint));
		msg.addBody(body);
		if (body.size() > 0)
		{
			attrib = HttpMessage::attribute("content-length", Converter<size_t>::toString(body.size()));
			msg.addAttribute(attrib);
		}
		break;
	default:
		msg.clear();
		msg.addAttribute(HttpMessage::attribute("Error", "unknown message type"));
	}
	return msg;
}

//----< this function handles the sending of messages to client >------------------

void MsgSender::sendMessage(HttpMessage& msg, Socket& socket)
{
	std::string msgString = msg.toString();
	socket.send(msgString.size(), (Socket::byte*)msgString.c_str());
}


//----< this function handles the sending of files to the client >------------------
bool MsgSender::sendFile(const std::string& filename, const std::string& packageName, Socket& socket)
{
	// assumes that socket is connected

	std::string fqname = "../RemoteRepository/"+ packageName+"/" + filename;
	FileSystem::FileInfo fi(fqname);
	size_t fileSize = fi.size();
	std::string sizeString = Converter<size_t>::toString(fileSize);
	FileSystem::File file(fqname);
	file.open(FileSystem::File::in, FileSystem::File::binary);
	if (!file.isGood())
		return false;
	HttpMessage msg = makeMessage(1, "", "localhost:8081");
	msg.addAttribute(HttpMessage::Attribute("file", filename));
	msg.addAttribute(HttpMessage::Attribute("Package", packageName));
	msg.addAttribute(HttpMessage::Attribute("content-length", sizeString));
	sendMessage(msg, socket);
	const size_t BlockSize = 2048;
	Socket::byte buffer[BlockSize];
	while (true)
	{
		FileSystem::Block blk = file.getBlock(BlockSize);
		if (blk.size() == 0)
			break;
		for (size_t i = 0; i < blk.size(); ++i)
			buffer[i] = blk[i];
		socket.send(blk.size(), buffer);
		if (!file.isGood())
			break;
	}
	file.close();
	return true;
}


//----< this function handles the int to string conversions >------------------
std::string intToString(long i)
{
	std::ostringstream out;
	out.fill('0');
	out << std::setw(2) << i;
	return out.str();
}


//----< this function handles the closing of checkin >------------------
/*It shifts the folder to the immutable area of the Repository*/

void ClientHandler::ClosingCheckin(std::string package)
{
	if (!FileSystem::Directory::exists("../ServerDump/" + package))
	{
		Show::write("\n\n  Doesn't exist " + package);
		return;
	}
	std::string fqname = "../ServerDump/" + package;
	SYSTEMTIME systime;
	GetSystemTime(&systime);
	std::string timestamp = "_" + intToString(systime.wDay) + "-" + intToString(systime.wHour)+ "-" + intToString(systime.wMinute) + "-" + intToString(systime.wSecond);
	FileSystem::Directory::create("../RemoteRepository/" + package + timestamp);
	std::string directorypath = "../RemoteRepository/" + package + timestamp;
	std::vector<std::string> XMLfiles = FileSystem::Directory::getFiles(fqname, "*.xml");
	for (size_t i = 0; i < XMLfiles.size(); ++i)
	{
		std::string newXMLFile;
		size_t j = XMLfiles[i].find(".xml");
		for (size_t k = 0; k < j; k++)
			newXMLFile += XMLfiles[i][k];
		FileSystem::File::copy(fqname + "/" + XMLfiles[i], directorypath + "/" + newXMLFile + timestamp + ".xml");
		FileSystem::File::remove(fqname + "/" + XMLfiles[i]);
	}
	std::vector<std::string> files = FileSystem::Directory::getFiles(fqname, "*.*");
	for (size_t i = 0; i < files.size(); ++i)
	{
		FileSystem::File::copy(fqname +"/"+ files[i], directorypath +"/"+ files[i]);
		FileSystem::File::remove(fqname + "/" + files[i]);
	}
	FileSystem::Directory::remove(fqname);
}



//----< this function creates the xml document >------------------

void ClientHandler::createXMLDocument(std::vector<std::string> dependency, std::string package)
{
	XmlWriter wtr;
	wtr.addDeclaration();
	wtr.start("metadata");
	XmlWriter sub2;
	sub2.start("name");
	sub2.addBody(package);
	sub2.end();
	wtr.addBody(sub2.xml());
	XmlWriter sub1;
	sub1.start("deps");
	for (size_t i = 0; i < dependency.size(); i++)
	{ //add dependencies
		XmlWriter sub3;
		sub3.start("dep");
		if (dependency[i] == "NULL")
			sub3.addBody(dependency[i]);
		else
			sub3.addBody(dependency[i]);
		sub3.end();
		sub1.addBody(sub3.xml());
	}
	sub1.end();
	wtr.addBody(sub1.xml());
	wtr.end();
	Show::write("\n  writing XML to file**** Demonstrating requirement 3**** " + package + ".xml" + "\n");
	Show::write(wtr.xml().c_str());
	std::ofstream out("../ServerDump/" + package+"/"+ package+".xml");
	if (out.good())
	{
		out << wtr.xml().c_str();
		out.close();
	}
	std::cout << "\n\n";
}


//----<Reads message attributes helper function >---------
/*this funcion calls the extraction of files function*/

void ClientHandler::readMessageHelper1(Socket& socket, HttpMessage& msg)
{
	std::string Extraction = msg.findValue("Extraction");
	std::string FromAddress = msg.findValue("fromAddr");
	std::string withDependencies = msg.findValue("withDependencies");
	MsgSender c1("localhost:8080");
	c1.executeExtraction(Extraction, FromAddress, withDependencies); // 50 messages 100 millisec apart
}

//----<Reads message attributes helper function >---------
/*this funcion calls the receiving of files function*/

void ClientHandler::readMessageHelper2(Socket& socket, HttpMessage& msg)
{
	std::string filename = msg.findValue("file");
	size_t contentSize;
	std::string sizeString = msg.findValue("content-length");
	if (sizeString != "")
		contentSize = Converter<size_t>::toValue(sizeString);
	else
		return;
	std::string Package = msg.findValue("Package");
	readFile(Package, filename, contentSize, socket);
	msg.removeAttribute("content-length");
	std::string bodyString = "<file>" + filename + "</file>";
	sizeString = Converter<size_t>::toString(bodyString.size());
	msg.addAttribute(HttpMessage::Attribute("content-length", sizeString));
	msg.addBody(bodyString);
}

//----<Reads message attributes helper function >---------

void ClientHandler::readMessageHelper3(Socket& socket, HttpMessage& msg)
{
	std::string filename = msg.findValue("file");
	msg.removeAttribute("content-length");
	std::string bodyString = "<file>" + filename + "</file>";
	std::string sizeString = Converter<size_t>::toString(bodyString.size());
	msg.addAttribute(HttpMessage::Attribute("content-length", sizeString));
	msg.addBody(bodyString);
}

//----<Reads message attributes helper function >---------

void ClientHandler::readMessageHelper4(Socket& socket, HttpMessage& msg)
{
	size_t numBytes = 0;
	size_t pos = msg.findAttribute("content-length");
	if (pos < msg.attributes().size())
	{
		numBytes = Converter<size_t>::toValue(msg.attributes()[pos].second);
		Socket::byte* buffer = new Socket::byte[numBytes + 1];
		socket.recv(numBytes, buffer);
		buffer[numBytes] = '\0';
		std::string msgBody(buffer);
		msg.addBody(msgBody);
		delete[] buffer;
	}
}

//----<Reads message attributes helper it handles the dpendency messages >---------


void ClientHandler::readMessageHelper5(Socket& socket, HttpMessage& msg)
{
	//dependency list received from client add it to xml
	std::string dependecy = msg.findValue("Dependency");
	std::vector<std::string> deps = parseFileString(dependecy);
	std::string Package = msg.findValue("Package");
	createXMLDocument(deps, Package);
	return ;
}

//----<Reads message attributes helper it handles the post messages >---------

void ClientHandler::readMessageHelper6(Socket& socket, HttpMessage& msg)
{
	std::string dependecy = msg.findValue("Dependency");
	std::string filename = msg.findValue("file");
	std::string Extraction = msg.findValue("Extraction");
	std::string FromAddress = msg.findValue("fromAddr");
	std::string Package = msg.findValue("Package");
	std::string Close = msg.findValue("Close");
	std::string Checkin = msg.findValue("Checkin");
	std::string sendFileList = msg.findValue("sendFileList");
	if (sendFileList != "")
	{
		Show::write("\n server recvd message contents: \""+sendFileList+" Command\"" );
		MsgSender c1("localhost:8080");
    	c1.sendFileList(FromAddress);
	}
	else if (dependecy != "")
		readMessageHelper5(socket, msg);
	else if (Extraction != "")
		readMessageHelper1(socket, msg);
	else if (Close != "")
	{
		ClosingCheckin(Close);
		msg.removeAttribute("content-length");
		std::string bodyString = "Checkin close command";
		std::string  sizeString = Converter<size_t>::toString(bodyString.size());
		msg.addAttribute(HttpMessage::Attribute("content-length", sizeString));
		msg.addBody(bodyString);
	}
	else if (filename != "")
		readMessageHelper2(socket, msg);
	else if (filename != "")
		readMessageHelper3(socket, msg);
	else // read message body
		readMessageHelper4(socket, msg);
}

//----<Reads message attributes >---------

HttpMessage ClientHandler::readMessage(Socket& socket)
{
  connectionClosed_ = false;
  HttpMessage msg;
  // read message attributes
  while (true)
  {
    std::string attribString = socket.recvString('\n');
    if (attribString.size() > 1)
    {
      HttpMessage::Attribute attrib = HttpMessage::parseAttribute(attribString);
      msg.addAttribute(attrib);
    }
    else
      break;
  }
  // If client is done, connection breaks and recvString returns empty string
  if (msg.attributes().size() == 0)
  {
    connectionClosed_ = true;
    return msg;
  }
  // read body if POST - all messages in this demo are POSTs
  if (msg.attributes()[0].first == "POST")
  {
      readMessageHelper6(socket, msg);
	  return msg;
  }
  return msg;
}


//----< read a binary file from socket and save >--------------------
/*
 * This function expects the sender to have already send a file message, 
 * and when this function is running, continuosly send bytes until
 * fileSize bytes have been sent.
 */
bool ClientHandler::readFile(const std::string& package, const std::string& filename, size_t fileSize, Socket& socket)
{
  if(!FileSystem::Directory::exists("../ServerDump/" + package))
	  FileSystem::Directory::create("../ServerDump/" + package);
  std::string fqname = "../ServerDump/" + package +"/" + filename;
  FileSystem::File file(fqname);
  file.open(FileSystem::File::out, FileSystem::File::binary);
  const size_t BlockSize = 2048;
  Socket::byte buffer[BlockSize];
  size_t bytesToRead;
  while (true)
  {
    if (fileSize > BlockSize)
      bytesToRead = BlockSize;
    else
      bytesToRead = fileSize;
    socket.recv(bytesToRead, buffer);
    FileSystem::Block blk;
    for (size_t i = 0; i < bytesToRead; ++i)
      blk.push_back(buffer[i]);
	if (file.isGood())
		file.putBlock(blk);
    if (fileSize < BlockSize)
      break;
    fileSize -= BlockSize;
  }
  file.close();
  return true;
}


//----< receiver functionality is defined by this function >---------

void ClientHandler::operator()(Socket socket)
{
   while (true)
  {
    HttpMessage msg = readMessage(socket);
    if (connectionClosed_ || msg.bodyString() == "quit")
    {
      Show::write("\n\n  clienthandler thread is terminating");
      break;
    }
    msgQ_.enQ(msg);
  }
}

//----< test stub >--------------------------------------------------

int main()
{
  ::SetConsoleTitle(L"HttpMessage Server - Runs Forever");

  Show::attach(&std::cout);
  Show::start();
  Show::title("\n  HttpMessage Server started");

  BlockingQueue<HttpMessage> msgQ;

  try
  {
    SocketSystem ss;
    SocketListener sl(8080, Socket::IP6);
    ClientHandler cp(msgQ);
    sl.start(cp);
   
    while (true)
    {
      HttpMessage msg = msgQ.deQ();
	  if (msg.bodyLength() > 0)
      Show::write("\n\n  server recvd message contents:\n" + msg.bodyString());
    }
  }
  catch (std::exception& exc)
  {
    Show::write("\n  Exeception caught: ");
    std::string exMsg = "\n  " + std::string(exc.what()) + "\n\n";
    Show::write(exMsg);
  }
  std::cin.get();
}