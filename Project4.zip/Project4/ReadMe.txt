ReadMe.txt

Folders to view:

Repository:
Its the repository storage.
Innitial state should be : contains more than 3 packages

ServerDump:
server dumps the packages here before the repository moves it to its storage.
The repository moves these packages to the immutable storage area only on reception of close command
Innitial state should be : contains 0 packages

ClientDump1
MsgClient1's extracted packages are received here.
Innitial state should be : contains 0 packages

ClientDump2
MsgClient2's extracted packages are received here.
Innitial state should be : contains 0 packages


Changing to TA inputs:

This applicatio does not have a gui.For the ease of operation the paths for checkin 
and extracts are assigned in the the execute function of MsgClient1 and MsgClient2. 
They can be easily changed to new paths. The dependencies are selected as the second
and thrid package in the Pack list of checkin function in the client packages. 
This can be changed by changing the index of Packlist. The extraction selects the third package for extraction.
This can be changed by changing the index of Packlist.

Demonstrating requirements:
MsgClient1 :
This client does: View the Repository folder for the checked in package 
 Checkin of package and closing the checkin:
	std::string PackagePath = "../TestFolder/TypeTable"; 
	std::string PackageName = "TypeTable";  
 Extraction with dependencies: 
	selected third folder in repository
	Check clientDump1 folder for received packages

MsgClient2 :
This client does:
 Versioning of packages:
	std::string PackagePath = "../TestFolder/TestFiles";
	std::string PackageName = "TestFiles";
Extraction without dependencies:
	selected third folder in repository
        Check clientDump2 folder for received packages
Checkin of package and keeping the checkin open:
        PackagePath = "../TestFolder/Logger";
	PackageName = "Logger";
Check ServerDump folder for package, it is not moved to immutable area of repository untill the client send the close checkin command.

Please note that the std::cin.get() command have been added in the main() function of server and 
clients so as to hold the window for viewing the console
