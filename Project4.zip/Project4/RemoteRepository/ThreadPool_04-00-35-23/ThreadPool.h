#ifndef THREADPOOL_H
#define THREADPOOL_H
///////////////////////////////////////////////////////////////////////
// ThreadPool.h -multiple child thread processes enqueued work items //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
//Source :Jim Fawcett,QueuedWorkItems package                        //
///////////////////////////////////////////////////////////////////////
/*

Module Operations:
==================
A multiple child thread processes work items equeued by main thread

Public Interface:
=================
start()                                              //start multiple child thread that dequeus work items
wait()                                                 //wait for child thread to terminate 
doWork() 				            			    //enqueue work 
setNumThreads()                                     // Sets the number of threads that would run in parallel

Build Process:
==============
Required files
-  - Cpp11-BlockingQueue.h, ThreadPCpp11-BlockingQueue.cpp, FunctorClass.h , FunctorClass.cpp,ThreadPool.h, ThreadPool.cpp,
Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
#include <thread>
#include <functional>
#include "Cpp11-BlockingQueue.h"
#include"../FunctorClass/FunctorClass.h"


using WorkItem = FunctorClass;

///////////////////////////////////////////////////////////////////////
// class to process work items


class ProcessWorkItem
{
public:
	ProcessWorkItem() {}
	void start();
	void setNumThreads(size_t _NoParallelThreads)
	{
		NoParallelThreads = _NoParallelThreads;
	}
	void doWork(WorkItem* pWi);
	void wait();
	~ProcessWorkItem();
private:
	size_t NoParallelThreads = 1;
	std::thread* _pThread[10];
	BlockingQueue<WorkItem*> _workItemQueue;
};
#endif