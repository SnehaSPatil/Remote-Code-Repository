///////////////////////////////////////////////////////////////////////
// DependencyAnaysis.cpp -acts on specfied files for finding dependency//
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#include "DependencyAnalysis.h"
#include"../ActionsAndRules/ActionsAndRules.h"

Depqueue_ depAnalysis::Dpq;

///////////////////////////////////////////////////////////////
// Does the dependency analysis on a single file 

void depAnalysis::doDepAnalysis(std::string filespec, TypeTable<TypeTableRecord> &table)
{
	configure.setPassNo(2); // Configures parser for the second pass 
	configure.setPtablePonter(&table);
	configure.setFileName(filespec);
	Parser* pParser = configure.Build();
	try
	{
		if (pParser)
		{
			if (!configure.Attach(filespec))
			{
				std::cout << "\n  could not open file " << filespec << std::endl;
			}
		}
		else
		{
			std::cout << "\n\n  Parser not built\n\n";
			return;
		}
		// now that parser is built, use it
		while (pParser->next())
			pParser->parse();
		std::cout << "\n\n";
	}
	catch (std::exception& ex)
	{
		std::cout << "\n\n    " << ex.what() << "\n\n";
	}
	std::cout << "\n\n";
}

///////////////////////////////////////////////////////////////
// Prints the contents of the unordered map

void depAnalysis::doprint()
{
	while (Dpq.size() != 0)
	{
		using FileAssociations = std::unordered_map<std::string, std::vector<std::string>>;
		FileAssociations* FileassoRecord = Dpq.deQ();
		std::unordered_map<std::string, std::vector<std::string>>::iterator i = FileassoRecord->begin();
		std::cout << "\n File: " << i->first << " depends on the following files:";

		for (size_t j = 0; j < i->second.size(); j++)
		{
			std::cout << "\nFile: " << i->second[j];
		}
		std::cout << "\n \n";
		delete FileassoRecord; // deleting the File records created with new
	}
}

///////////////////////////////////////////////////////////////
// Enqueues to the results queue for dependency analysis

void depAnalysis::doEnqueue()
{
	FileAssociations *FileassoRecord = configure.getFileAssociations();
	Dpq.enQ(FileassoRecord);
}
