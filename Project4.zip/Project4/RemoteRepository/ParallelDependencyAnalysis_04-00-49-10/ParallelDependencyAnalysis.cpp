///////////////////////////////////////////////////////////////////////
// ParallelDependencyAnalysis.cpp -evaluates the dependency graph for//
// all the packages in a specified file collection                   //
// and dependency analysis                                           //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#include "ParallelDependencyAnalysis.h"
#include"../Tasks/Task.h"

using Util = Utilities::StringHelper;


queue_ pDepAnalysis::Typq;
BlockingQueue<FunctorClass*> pDepAnalysis::createdFunct;

///////////////////////////////////////////////////////////////
// Creates the task which would carry out the Type analysis 

void pDepAnalysis::pass1(std::string filespecs)
{	
	if (filespecs != "End of Files")
	{	
		FunctorClass *typAl = new FunctorClass(filespecs,1,&Typq);
		WorkItem *wi = typAl;
		task task(wi);
		createdFunct.enQ(typAl);
	}
	// end of file reached
	else
	{
		FunctorClass *typAl = new FunctorClass(filespecs, 3,&Typq);
		WorkItem *wi = typAl;
		task task(wi);
		task.signalStop();
		task.wait();
		task.reset();
		createdFunct.enQ(typAl);
	}
			
}

///////////////////////////////////////////////////////////////
// Does the merging of partial symbol tables


void pDepAnalysis::doMerge(TypeTable<TypeTableRecord>& table)
{
	TypeTable<TypeTableRecord> Tabeltemp;
	while (Typq.size()!= 0)
	{
		TypeTable<TypeTableRecord> *_ptable = Typq.deQ();
		std::unordered_map<std::string, TypeTableRecord>::iterator itr = _ptable->begin();
		while (itr != _ptable->end())
		{
			Tabeltemp.addRecord(itr->first, itr->second);
			itr++;
		}
		delete _ptable; // deleting the partial tables created with new
	}
	table = Tabeltemp;
	showTypeTable(table);
}



///////////////////////////////////////////////////////////////
// Creates the task which would carry out the dependency analysis 


void pDepAnalysis::pass2(std::string filespecs, TypeTable<TypeTableRecord> &Table)
{
	if (filespecs != "End of Files")
	{
		FunctorClass *depAl = new FunctorClass(filespecs, Table,2);
		WorkItem *wi = depAl;
		task task(wi);
		createdFunct.enQ(depAl);
	}
	// end of file reached
	else
	{
		FunctorClass *depAl = new FunctorClass(filespecs, Table, 3);
		WorkItem *wi = depAl;
		task task(wi);
		task.signalStop();
		task.wait();
		task.reset();
		createdFunct.enQ(depAl);
	}
}

///////////////////////////////////////////////////////////////
// Print the dependency analysis result
void pDepAnalysis::doPrint()
{
	//This display prints the analysis results on two adjacent lines without the full file path
	//dpalys.display(); 
	//This prints the full file path
	dpalys.doprint();
}


//Test Stub for Parallel Dependency Analysis

#ifdef TEST_PARALLELDEPENDENCYANALYSIS
#include "../FileMgr/FileMgr.h"
#include <iostream>

struct FileHandler : IFileEventHandler
{
	TypeTable<TypeTableRecord>& getTypeTable()
	{
		return Table;
	}
	void setTypeTable(TypeTable<TypeTableRecord>& table)
	{
		Table = table;
	}
	pDepAnalysis* pDepAnalysisPointer()
	{
		return PDep;
	}
	std::vector<std::string> savedFiles()
	{
		return saveFiles;
	}
	void execute(const std::string& fileSpec)
	{
		std::cout << "\n  --   " << fileSpec;
		saveFiles.push_back(fileSpec);
		if (passNo == 1)
			PDep->pass1(fileSpec);
		else if (passNo == 2)
			PDep->pass2(fileSpec, Table);
	}
	void setPassNo(size_t _passNo)
	{
		passNo = _passNo;
	}
private:
	std::vector<std::string> saveFiles;
	pDepAnalysis *PDep;
	size_t passNo = 1;
	TypeTable<TypeTableRecord> Table;
};


int main(int argc, char* argv[])
{
	std::cout << "\n  Testing Parallel Dependency Executive";
	std::cout << "\n =================";
	try
	{
		std::string path = FileSystem::Path::getFullFileSpec(argv[1]);
		//std::cout << "\n path = " << path;
		IFileMgr* pFmgr = FileMgrFactory::create(path);
		FileHandler fh;
		pDepAnalysis *PDep = fh.pDepAnalysisPointer();
		pFmgr->regForFiles(&fh);
		pFmgr->addPattern("*.h");
		pFmgr->addPattern("*.cpp");
		pFmgr->search();
		PDep->pass1("End of Files");
		TypeTable<TypeTableRecord> Table = fh.getTypeTable();
		PDep->doMerge(Table);
		fh.setTypeTable(Table);
		std::vector<std::string> savedFiles = fh.savedFiles();
		fh.setPassNo(2);
		pFmgr->search();
		PDep->pass2("End of Files", Table);
		PDep->doPrint();
	}
	catch (std::exception& ex)
	{
		std::cout << "\n\n    " << ex.what() << "\n\n";
	}
	std::cout << "\n\n";
}
#endif