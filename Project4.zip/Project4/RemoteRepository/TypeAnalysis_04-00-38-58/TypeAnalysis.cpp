///////////////////////////////////////////////////////////////////////
// TypeAnaysis.cpp -acts on specfied file for building partial symbol//
// table. Also povides function to merge the partial tables          //                                                           
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#include"TypeAnalysis.h"
#include"../ActionsAndRules/ActionsAndRules.h"


///////////////////////////////////////////////////////////////
// Does the type analysis on a single file to form the partial symbol table

void typeAnalysis::doTypAnalysis(std::string filespec, TypeTable<TypeTableRecord> *_ptable)
{
	ConfigParseToConsole configure;
	configure.setPassNo(1); // Configures parser for the first pass 
	configure.setPtablePonter(_ptable);
	configure.setFileName(filespec);
	Parser* pParser = configure.Build();
	try
	{
		if (pParser)
		{
			if (!configure.Attach(filespec))
			{
				std::cout << "\n  could not open file " << filespec << std::endl;
			}
		}
		else
		{
			std::cout << "\n\n  Parser not built\n\n";
			return ;
		}
		// now that parser is built, use it
		while (pParser->next())
			pParser->parse();
		std::cout << "\n\n";
	}
	catch (std::exception& ex)
	{
		std::cout << "\n\n    " << ex.what() << "\n\n";
	}
	std::cout << "\n\n";

}


//Test Stub for Deendency Analysis

#ifdef TEST_TYPEANALYSIS
#include "../TypeAnalysis/TypeAnalysis.h"

int main(int argc, char* argv[])
{
	std::cout << "\n  Testing DependencyAnalysis \n "
		<< std::string(30, '=') << std::endl;
	std::string fileSpec1 = "../Parser/Praser.cpp";
	std::string fileSpec2 = "../Parser/Praser.h";
	typeAnalysis typeAlys;
	TypeTable<TypeTableRecord> *ptble1, *ptble2, SymboleTable;
	typeAlys.doTypAnalysis(fileSpec1, ptble1);
	typeAlys.doTypAnalysis(fileSpec2, ptble2);
	BlockingQueue<TypeTable<TypeTableRecord>*> _resultsQueue;
	_resultsQueue.enQ(ptble1);
	_resultsQueue.enQ(ptble2);
}
#endif